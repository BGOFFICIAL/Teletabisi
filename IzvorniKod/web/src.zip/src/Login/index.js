import React from 'react';
import { useLocalState } from '../util/useLocalStorage';
import { useEffect } from 'react';
import { useState } from 'react';
import {jwtDecode} from "jwt-decode";
import { LogOut } from '../services/LogOut';



const Login = () => {
    const [username,setUsername]=useState("");
    const [password,setPassword]=useState("");

    const [jwt,setJwt] = useLocalState("", "jwt");
    const [loginSource, setLoginSource] = useState("","loginSource");
    const [roles,setRoles] = useLocalState(UseGetRoleFromJWT);
      
    
    if(jwt){
        const decoded = jwtDecode(jwt);
        console.log(decoded.authorities);
        console.log("Ovo vracas:"+decoded.roles[0].authority );
        if(decoded.roles[0].authority === "ADMIN"){
          window.location.href = "/admin";
          return <div>Loading....</div>
        }
        if(decoded.roles[0].authority === "USER"){
          window.location.href = "/user";
          return <div>Loading....</div>
        }
      }

      function UseGetRoleFromJWT(){    
        if(jwt){
          const decoded = jwtDecode(jwt);
          console.log(decoded.authorities);
          
          return decoded.roles[0].authority;
        }
        else{
          return "";
        }
    }



    

    console.log(username);
    console.log(password);
    let pom =false;


    function sendLoginRequest() {
      

      pom=false;

        console.log("kliknut")
          const reqBody= {
          "username": username,
          "password": password,
          };

        
    
      
          fetch("http://localhost:8080/api/v1/auth/authenticate", {
            "headers": {
            "Content-Type": "application/json",
          },
            "method": "POST",
            
            body: JSON.stringify(reqBody),
            })
              .then(response => {
                if(response.status === 200){
                  pom=true;
                  
                  setLoginSource(true);
                  return response.json();
                 
                }
                else{
                    console.log("nije usao");
                  return Promise.reject("Invalid username or password");
                    
                }})
              .then((data) => {
                if(pom===true){
                console.log("usao",data.token);
             setJwt(data.token);
             window.location.href = "/user";
                }
            }).catch((error) => {
            console.error("Error:",error);
            });
      };
    

  


    return (
        <>
        <div>
            <label>Username</label>
            <input type="username" id="username" value={username} onChange={(event) => setUsername(event.target.value)}/>
        </div>
        <div>
            <label>Password</label>
            <input type="password" id="password" value={password} onChange={(event)=> setPassword(event.target.value)}/>
        </div>
        <div>
            <button id="submit" type="button" onClick={() => sendLoginRequest()}>Login</button>
        </div>


       

      </>
    );
    };

export default Login;