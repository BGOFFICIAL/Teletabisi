import React from 'react';
import { useLocalState } from '../util/useLocalStorage';
import { useEffect,useState } from 'react';
import { LogOut } from '../services/LogOut';
import Settings from '../Settings';
import {jwtDecode} from "jwt-decode";






const User = () => {
    const [jwt,setJwt] = useLocalState("", "jwt");
      const [roles,setRoles] = useLocalState(UseGetRoleFromJWT);
      if(jwt){
        try{
        const decoded = jwtDecode(jwt);
        
        console.log(decoded.authorities);
        console.log("Ovo vracas:"+decoded.roles[0].authority );
        if(decoded.roles[0].authority === "ADMIN"){
            window.location.href = "/admin";
            return <div>Loading....</div>
         
        }else if(decoded.roles[0].authority !== "USER"){
            window.location.href = "/welcome";
            
        }
      }
    catch(error){
        window.location.href = "/welcome";
        return <div>Loading....</div>
       }}

      function UseGetRoleFromJWT(){    
        if(jwt){
          const decoded = jwtDecode(jwt);
          console.log(decoded.authorities);
          
          return decoded.roles[0].authority;
        }
        else{
          return "";
        }
    }
    
    console.log("idem dalje");

    
    

    return (
        <div>

            <h1>Usao si</h1>
            <div>jtw is {jwt}</div>
            <div>
            <button id="logout" type="button" onClick={() => LogOut()}>LogOut</button>
            </div>

            <div>
            <button id="settings" type="button" onClick={() => window.location.href = "/settings"}>Settings</button>
            </div>

        </div>
    );
};

export default User;