const Employees = [
    {
      
            name: "",
            surname: "",
            email: "",
            date_Of_Birth: "",
            start_date:"",
            gender:"",
          
    
    }
]
    
export default Employees;