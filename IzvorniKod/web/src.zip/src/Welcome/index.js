import React from 'react';
import './index.css';
import { useLocalState ,useEffect} from '../util/useLocalStorage';
import {jwtDecode} from 'jwt-decode';
import { LogOut } from '../services/LogOut';

const Welcome = () => {
      const [jwt,setJwt] = useLocalState("", "jwt");
      const [roles,setRoles] = useLocalState(UseGetRoleFromJWT);
      if(jwt){
        try{
        const decoded = jwtDecode(jwt);
        console.log(decoded.authorities);
        console.log("Ovo vracas:"+decoded.roles[0].authority );
        if(decoded.roles[0].authority === "ADMIN"){
       
          window.location.href = "/admin";
          return <div>Loading....</div>
        }
        if(decoded.roles[0].authority === "USER"){
          window.location.href = "/user";
          return <div>Loading....</div>
        }
      }catch(error){
        LogOut();
        return <div>Loading....</div>
      };
    }
      function UseGetRoleFromJWT(jwt){    
        if(jwt){
          const decoded = jwtDecode(jwt);
          console.log(decoded.authorities);
          
          return decoded.roles[0].authority;
        }
        else{
          return "";
        }
    }
      

      


    
   

  

    return (
        <div className="container-fluid">
      {/* Row 1 */}
      <div className="row row-highlight">
        <div className="col">
          {/* Your logo goes here */}
          <img src="path/to/your/logo.png" alt="Logo" className="logo" />
        </div>
        <div className="col-5"></div>
        <div className="col-3 col-text">
          <h3>Jwt is {jwt}</h3>
        </div>
        <div className="col"></div>
      </div>

      {/* Row 2 */}
      <div className="row row-background">
        <div className="col-3 col-text">
          <h3>Thank you for choosing us</h3>
        </div>
        <div className="col-5"></div>
        <div className="col-3"></div>
      </div>

      {/* Row 3-5 */}
      <div className="row row-background">
        <div className="col-3 col-text">
          {/* Description of your app */}
          <p>Description of our app goes here.</p>
        </div>
        <div className="col-5"></div>
        <div className="col-3"></div>
      </div>

      {/* Row 6 */}
      <div className="row row-background">
        <div className="col-2"></div>
        <div className="col-3">
          {/* Register button */}
          <button className="btn btn-primary btn-register">Register</button>
        </div>
        <div className="col-2"></div>
      </div>

      {/* Row 7 */}
      <div className="row row-highlight">
        <div className="col"></div>
        <div className="col-5"></div>
        <div className="col-3">
          {/* Login button */}
          <button className="btn btn-primary btn-login">Login</button>
        </div>
        <div className="col"></div>
      </div>
    </div>
 
    );
};

export default Welcome;