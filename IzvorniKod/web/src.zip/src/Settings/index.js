import React from 'react';
import { useLocalState } from '../util/useLocalStorage';
import { useEffect } from 'react';
import { useState } from 'react';



const Settings = () => {
    const [username,setUsername]=useState("");
    const [password,setPassword]=useState("");
    const [email,setEmail]=useState("");


    const [jwt,setJwt] = useLocalState("", "jwt");
    const [loginSource, setLoginSource] = useState("","loginSource");

    

    console.log(username);
    console.log(password);
    let pom =false;


    function sendSettingsRequest() {
 

        console.log("kliknut")
          const reqBody= {
          "username": username,
          "password": password,
          "email": email,
          };

          console.log("Bearer :" + jwt);

        
    
      
          fetch("http://localhost:8080/api/v1/auth/update", {
            "headers": {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + jwt,
          },
           
            "method": "POST",
            body: JSON.stringify(reqBody),
            })
              .then(response => {
                if(response.status === 200){
                  return response.json();
                }
                else{
                    console.log("nije usao");
                  return Promise.reject("Invalid username or password");
                    
                }})
              .catch((error) => {
            console.error("Error:",error);
            });
      };
    
    

  


    return (
        <>
        <div>
            <label>Username</label>
            <input type="username" id="username" value={username} onChange={(event) => setUsername(event.target.value)}/>
        </div>
        <div>
            <label>Password</label>
            <input type="password" id="password" value={password} onChange={(event)=> setPassword(event.target.value)}/>

        </div>
        <div>
            <label>Email</label>
            <input type="email" id="email" value={email} onChange={(event)=> setEmail(event.target.value)}/>
        </div>
        <div>
            <button id="submit" type="button" onClick={() => sendSettingsRequest()}>Settings</button>
        </div>

       

      </>
    );
    };

export default Settings;